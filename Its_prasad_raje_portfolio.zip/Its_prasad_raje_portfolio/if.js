 switch (color) {
        case ("Mi marathi"):
            console.log("stop");
            break;
    
        case ("green"):
            console.log("go");
            break;
    
        case ("Yello"):
            console.log("Ready for go");
            break;
    
        case ("Wong color"):
            console.log("hi prasad")
 }
    