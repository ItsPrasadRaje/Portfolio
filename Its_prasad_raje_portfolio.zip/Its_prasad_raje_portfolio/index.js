// Toggle the mobile menu
function toggleMenu() {
    const navbarLinks = document.querySelector('.navbar-links');
    navbarLinks.classList.toggle('active');
}






$(document).ready(function () {
        $("#b1").click(function () {
            $(".img1").show();
            $(".img2").hide();
        });
        $("#b2").click(function () {
            $(".img1").hide();
            $(".img2").show();
        });
      
    });

